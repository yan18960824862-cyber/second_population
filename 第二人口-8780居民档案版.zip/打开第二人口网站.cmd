@echo off
cd /d "%~dp0second-population-v1-work"
set "PREVIEW_PY=python"
if exist "D:\python\python.exe" set "PREVIEW_PY=D:\python\python.exe"
echo Keep this window open while viewing the website.
"%PREVIEW_PY%" -c "import http.server,webbrowser; server=http.server.ThreadingHTTPServer(('127.0.0.1',0),http.server.SimpleHTTPRequestHandler); url='http://127.0.0.1:'+str(server.server_port)+'/index.html'; print(url,flush=True); webbrowser.open(url); server.serve_forever()"
pause
