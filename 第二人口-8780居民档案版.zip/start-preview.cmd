@echo off
cd /d "%~dp0second-population-v1-work"
echo SECOND POPULATION (8780 edited) / http://127.0.0.1:8071/
node tools\preview.cjs "%CD%" 8071
