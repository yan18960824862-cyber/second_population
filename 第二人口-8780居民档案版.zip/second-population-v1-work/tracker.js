/* ═══════════════════════════════════════════════════
   TRACKER.JS — 识别模块
   职责：加载 tracks.json 坐标数据 → 按视频时间轴插值
   渲染识别框 → 跟随 / 悬停高亮 / 点击返回统一 objectId
   ═══════════════════════════════════════════════════ */
"use strict";

(async function () {
  const video      = document.getElementById("cam");
  const layer      = document.getElementById("trackLayer");
  const viewport   = document.getElementById("viewport");
  const layout     = document.querySelector(".layout");
  const timelineHandle = document.getElementById("timelineHandle");
  const timelineTip    = document.getElementById("timelineTip");
  const idToast    = document.getElementById("idToast");
  const playBtn    = document.getElementById("playBtn");
  const timeline   = document.getElementById("timeline");
  const timelineFill = document.getElementById("timelineFill");
  const timecode   = document.getElementById("timecode");
  const recTime    = document.getElementById("recTime");
  const hudClock   = document.getElementById("hudClock");
  const detectCount = document.getElementById("detectCount");
  const detectTotal = document.getElementById("detectTotal");
  const targetList = document.getElementById("targetList");
  const statObjects = document.getElementById("statObjects");
  const statEnergy  = document.getElementById("statEnergy");
  const statWater   = document.getElementById("statWater");
  const statPersons = document.getElementById("statPersons");
  const tpPct       = document.getElementById("tpPct");
  const tpBar       = document.getElementById("tpBar");
  const tpCount     = document.getElementById("tpCount");
  const tpTotal     = document.getElementById("tpTotal");
  const camLabel    = document.getElementById("camLabel");
  const zoneLabel   = document.getElementById("zoneLabel");
  const sceneNav    = document.getElementById("sceneNav");


  /* 面板（panels.js）：数据可视化 / 3D 群像 / 档案库 / 实时代码 */
  const Panels = window.Panels || {
    dataViz: { update() {} }, crowd: { update() {} },
    library: { build() {}, markActive() {} }, code: { update() {} }
  };

  /* Unified registry: four B captures plus A's separately timed legacy take. */
  const SCENES = Object.fromEntries((await window.Census.ready).scenes.map(s=>[s.key,{...s,tracks:s.sourceFile}]));
  let scenePromise=Promise.resolve();
  let discoveredIds=new Set();

  let objects = [];
  let duration = 30;
  let maxEnergy = 1;
  let order = [];
  let idToOrderIndex = new Map();
  let currentOrderIndex = 0;
  let currentScene = null;
  let loadToken = 0;

  /* ── 框层与视频实际渲染区域对齐（contain / cover） ── */
  function applyFit(videoEl, layerEl, mode) {
    if (!videoEl || !layerEl || !videoEl.videoWidth) return;
    const cw = videoEl.clientWidth, ch = videoEl.clientHeight;
    const vw = videoEl.videoWidth, vh = videoEl.videoHeight;
    if (!cw || !ch) return;
    const s = mode === "cover" ? Math.max(cw / vw, ch / vh) : Math.min(cw / vw, ch / vh);
    const w = vw * s, h = vh * s;
    layerEl.style.left = ((cw - w) / 2) + "px";
    layerEl.style.top = ((ch - h) / 2) + "px";
    layerEl.style.width = w + "px";
    layerEl.style.height = h + "px";
  }

  const mainLayer = layer; // #trackLayer
  let lastMainSize = "";
  // 缓存 #trackLayer 的像素尺寸，供 transform:translate 定位使用
  // （只在 resize 时同步读取一次，避免每帧读 clientWidth 触发同步布局）
  let layerW = 0, layerH = 0;
  let lastT = 0;   // 帧间时间戳，用于缓动 dt

  /* ── 状态 ── */
  let selectedId = null;
  let focusId = null;
  let manualFocus = false;
  let toastTimer = null;
  const boxEls = new Map();   // objectId → DOM
  const lockEls = new Map();  // objectId → 档案卡内锁定进度条 <i>
  const listEls = new Map();  // objectId → li

  // 空调档案模块（v7 handoff）：同源 iframe 集成状态
  const acFrame = document.getElementById("acArchive");
  const acFrameClose = document.getElementById("acArchiveClose");
  let acApi = null;
  let acArchiveOpen = false;
  let acCloseBound = false;

  /* ── 局部虚框：优先取数据内的 parts，否则按类别推断（沿用 4 场景版本） ── */
  function partFor(obj) {
    if (obj.parts) return obj.parts;
    const en = obj.labelEn || "";
    if (obj.category === "person")         return { l: 27, t: 2, w: 46, h: 20, name: "HEAD" };
    if (/BARRIER|CONE|BOLLARD/.test(en))   return { l: 6,  t: 10, w: 88, h: 78, name: "CHEVRON" };
    if (/LUMINAIRE|CAMERA POLE/.test(en))  return { l: 26, t: 0,  w: 48, h: 18, name: "LAMP HEAD" };
    if (/METRO|GANTRY|SIGN/.test(en))      return { l: 6,  t: 6,  w: 88, h: 56, name: "PANEL" };
    if (/BANNER/.test(en))                 return { l: 8,  t: 8,  w: 84, h: 60, name: "PRINT" };
    if (/TAXI/.test(en))                   return { l: 34, t: 0,  w: 32, h: 16, name: "ROOF SIGN" };
    if (/BIKE RACK/.test(en))              return { l: 2,  t: 30, w: 96, h: 44, name: "WHEELSET" };
    if (/KERB|FENCE|GUARDRAIL/.test(en))   return { l: 0,  t: 26, w: 100, h: 46, name: "RAIL" };
    if (/TREE|SHRUB|HEDGE/.test(en))       return { l: 30, t: 4,  w: 40, h: 48, name: "CANOPY" };
    if (/ASPHALT|LANE MARK/.test(en))      return null; // 基底面层不画局部框
    if (/ARROW|LANE MARK|MANHOLE/.test(en))return { l: 18, t: 18, w: 64, h: 56, name: "MARK" };
    if (/BUS|COACH/.test(en))              return { l: 6,  t: 6,  w: 88, h: 32, name: "WINDOW" };
    if (/TRUCK|VAN/.test(en))              return { l: 4,  t: 6,  w: 56, h: 46, name: "CARGO" };
    if (obj.category === "industrial")     return { l: 12, t: 10, w: 76, h: 70, name: "ASSEMBLY" };
    if (obj.category === "infrastructure") return { l: 30, t: 0,  w: 40, h: 26, name: "LAMP" };
    return { l: 14, t: 8, w: 60, h: 44, name: "CABIN" };
  }

  /* ── 档案卡挂载方向：贴右边界改左挂，贴顶边改下挂（沿用 4 场景版本） ── */
  const CARD_W = 176;
  const CARD_H = 210;
  function placeCard(box) {
    const lr = layer.getBoundingClientRect();
    const br = box.getBoundingClientRect();
    const leftIn = br.left - lr.left;
    const topIn = br.top - lr.top;
    const sideW = (document.querySelector(".sidebar") || {}).offsetWidth || 232;
    const toLeft = leftIn + 14 + CARD_W > lr.width - 4;
    box.classList.toggle("align-r", toLeft);
    const off = toLeft ? 14 : Math.max(14, sideW + 16 - leftIn);
    box.style.setProperty("--card-x", off + "px");
    box.classList.toggle("side-b", topIn < CARD_H);
  }

  /* ── 构建左侧目标清单（按场景重建） ── */
  function buildSceneUI() {
  // 切换场景时先清空上一场景的清单 / 识别框 / 映射
  targetList.innerHTML = "";
  layer.querySelectorAll(".track-box").forEach((el) => el.remove());
  boxEls.clear(); lockEls.clear(); listEls.clear();

  // 档案遍历顺序（按出现时间排序），供上/下一个目标使用
  order = objects.slice().sort((a, b) => a.appear - b.appear);
  idToOrderIndex = new Map(order.map((o, i) => [o.objectId, i]));
  currentOrderIndex = 0;

  detectTotal.textContent = "/ " + String(objects.length).padStart(2, "0");
  tpTotal.textContent = String(objects.length).padStart(2, "0");
  objects.forEach((obj) => {
    const li = document.createElement("li");
    li.className = "target-item" + (obj.isAc ? " ac-item" : "");
    li.dataset.id = obj.objectId;
    const acBadge = obj.isAc ? '<span class="ac-badge">AC</span>' : "";
    const timeText = obj.isAc
      ? "固定目标 · 点击进入空调档案"
      : "出现 " + obj.appear.toFixed(1) + "s — " + obj.disappear.toFixed(1) + "s · CONF " + obj.conf.toFixed(2);
    li.innerHTML =
      '<div class="t-name"><span><span class="t-status"></span>' + obj.label + acBadge + "</span>" +
      '<span class="t-id">' + obj.objectId + "</span></div>" +
      '<div class="t-time">' + timeText + "</div>";
    li.addEventListener("click", () => {
      video.currentTime = obj.appear + 0.05;
      selectObject(obj.objectId);
    });
    targetList.appendChild(li);
    listEls.set(obj.objectId, li);
  });

  /* ── 为每个目标创建识别框 DOM ── */
  objects.forEach((obj) => {
    const box = document.createElement("div");
    // person 类别 → 白色描边（参考图：人物框为白色）
    box.className = "track-box cat-" + (obj.category || "default") + (obj.isAc ? " ac-box" : "");
    box.dataset.id = obj.objectId;
    box.dataset.canonicalId = obj.canonicalId;
    box.style.display = "none";
    const en = obj.labelEn || obj.label || obj.objectId;
    const p = partFor(obj);
    const energyPct = Math.min(100, Math.round(((obj.energyKwh || 0) / 45000) * 100));
    const midT = ((obj.appear + obj.disappear) / 2).toFixed(1);
    const mode = obj.category === "person" ? "RUN"
               : obj.category === "vehicle" ? "MOVE"
               : obj.category === "industrial" ? "FIXED" : "STATIC";
    const acBadge = obj.isAc ? '<span class="ac-mark">AC</span>' : "";

    box.innerHTML =
      '<span class="c"></span>' +
      '<div class="box-ruler">' +
        '<span class="r-top">M</span>' +
        '<span class="r-scale"></span>' +
        '<span class="r-word">' + mode + "</span>" +
      "</div>" +
      (p
        ? '<div class="box-part" style="left:' + p.l + "%;top:" + p.t +
          "%;width:" + p.w + "%;height:" + p.h + '%"><span>' + p.name + "</span></div>"
        : "") +
      '<div class="box-tag"><span>' + en + "</span>" +
        '<span class="tid">' + obj.objectId + "</span>" + acBadge + "</div>" +
      '<div class="box-card">' +
        '<div class="card-leader"></div>' +
        '<div class="card-tag">' +
          '<span class="t-label">' + en + "</span>" +
          '<span class="t-conf">' + obj.conf.toFixed(2) + "</span>" +
          '<span class="lock"><i></i></span>' +
        "</div>" +
        '<div class="card-id"><span class="k">ID:</span><span class="v">' + obj.objectId + "</span></div>" +
        '<div class="card-photo">' +
          '<img src="' + obj.thumb + '" alt="" onerror="this.remove()">' +
          '<span class="ph-cap">EVIDENCE · T+' + midT + "s</span>" +
        "</div>" +
        '<div class="card-rows">' +
          '<div class="card-row"><span class="k">TYPE</span><span class="v">' +
            (obj.category || "—").toUpperCase() + "</span></div>" +
          '<div class="card-row"><span class="k">FUNC</span><span class="v">' +
            (obj.function || "—") + "</span></div>" +
          '<div class="card-row"><span class="k">TRACK</span><span class="v">' +
            obj.appear.toFixed(1) + " – " + obj.disappear.toFixed(1) + "s</span></div>" +
        "</div>" +
        '<div class="card-chip" hidden><span>ENERGY</span>' +
          '<b><i style="width:' + energyPct + '%"></i></b>' +
          "<em>" + (obj.energyKwh || 0).toLocaleString("en-US") + "</em></div>" +
      "</div>";

    box.addEventListener("click", (e) => {
      e.stopPropagation();
      selectObject(obj.objectId);
    });
    box.addEventListener("mouseenter", () => {
      window.Census.emit('hover',{canonicalId:obj.canonicalId,active:true});
      focusId = obj.objectId;
      manualFocus = true;
      box.classList.add("focused");
      placeCard(box);
    });
    box.addEventListener("mouseleave", () => {
      window.Census.emit('hover',{canonicalId:obj.canonicalId,active:false});
      if (manualFocus && focusId === obj.objectId) manualFocus = false;
      box.classList.remove("focused");
    });

    // 背景型目标视觉后退，让交通主体更突出
    if (/^(FENCE|KERB|HEDGE|SHRUB|TREE|ARROW|ASPHALT|LANE MARK|CROSSWALK|BIKE RACK)$/.test(en)) {
      box.classList.add("bg");
    }
    if (obj.category !== "vehicle" && obj.category !== "person") {
      box.classList.add("aux", "bg");
    }
    if (obj.category === "vehicle" || obj.category === "person") {
      box.classList.add("subject");
    }

    layer.appendChild(box);
    boxEls.set(obj.objectId, box);
    lockEls.set(obj.objectId, box.querySelector(".card-tag .lock i"));
  });

  /* ── 右侧目标蛛网：点位 ↔ 识别框 / 清单行联动 ──
     包 try/catch：蛛网只是辅助视图，出问题不能连累识别框 / 标签的构建 */
  if (window.ObjectWeb) {
   try {
    window.ObjectWeb.build(objects, {
      onSelect: function (oid) {
        const obj = objects.find((o) => o.objectId === oid);
        if (!obj) return;
        const maxT = video.duration || duration;
        video.currentTime = Math.min(maxT, obj.appear + 0.05);
        selectObject(oid);
      },
      onHover: function (oid, on) {
        const b = boxEls.get(oid);
        if (b) b.classList.toggle("web-hover", on);
        const li = listEls.get(oid);
        if (li) li.classList.toggle("web-hover", on);
      }
    });
   } catch (e) { console.warn("[ObjectWeb] 蛛网构建失败，识别框不受影响", e); }
  }
  }

  /* ── 关键帧 Catmull-Rom 样条插值（比线性更顺滑，消除折线顿挫） ── */
  function cr(p0, p1, p2, p3, t) {
    const t2 = t * t, t3 = t2 * t;
    return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
  }
  function sampleProp(kfs, t, key) {
    if (t <= kfs[0].t) return kfs[0][key];
    const last = kfs[kfs.length - 1];
    if (t >= last.t) return last[key];
    let i = 0;
    while (i < kfs.length - 1 && !(t >= kfs[i].t && t <= kfs[i + 1].t)) i++;
    const p1 = kfs[i], p2 = kfs[i + 1];
    const seg = (t - p1.t) / ((p2.t - p1.t) || 1);
    const p0 = kfs[i - 1] || p1;   // 端点处退化为线性，避免越界
    const p3 = kfs[i + 2] || p2;
    return cr(p0[key], p1[key], p2[key], p3[key], seg);
  }
  function interpolate(kfs, t) {
    return {
      x: sampleProp(kfs, t, "x"),
      y: sampleProp(kfs, t, "y"),
      w: sampleProp(kfs, t, "w"),
      h: sampleProp(kfs, t, "h")
    };
  }

  /* ── 点击选中 → 返回统一 objectId ── */
  function selectObject(objectId, idx, returnSnapshot) {
    const obj = objects.find((o) => o.objectId === objectId);
    if (!obj) return;
    selectedId = obj.objectId;

    if (idx != null) currentOrderIndex = idx;
    else currentOrderIndex = idToOrderIndex.get(objectId) ?? 0;

    focusId = obj.objectId;
    manualFocus = true;

    // 高亮选中 + 弹出证据卡（悬停 / 选中均可触发，沿用 4 场景版本风格）
    boxEls.forEach((el, id) => {
      const on = id === obj.objectId;
      el.classList.toggle("selected", on);
      if (on) { el.classList.add("focused"); placeCard(el); }
      else el.classList.remove("focused");
    });
    listEls.forEach((el, id) => el.classList.toggle("selected", id === obj.objectId));
    showToast("objectId → " + obj.objectId);

    window.Census.emit('select',{canonicalId:obj.canonicalId,sourceId:obj.objectId,sceneId:currentScene});
    if(obj.category==='industrial' && /LUMINAIRE|STREETLIGHT/.test(obj.labelEn)){openObjectArchive({...obj,category:'infrastructure',sourceCategory:obj.category});return;}

    // 空调目标：打开全屏 v7 专用档案模块
    if (obj.isAc) { if (objArchiveOpen) closeObjectArchive(); openAcArchive(); return; }

    // 其余目标：打开全屏 OBJECT ARCHIVE（扫描 → 档案两段式）
    openObjectArchive(obj);
  }

  // 上一个 / 下一个目标：按顺序跳转并把视频拉到该目标出现时刻
  function goToOrder(delta) {
    const n = order.length;
    const next = ((currentOrderIndex + delta) % n + n) % n;
    const obj = order[next];
    const maxT = video.duration || duration;
    video.currentTime = Math.min(maxT, obj.appear + 0.1);
    selectObject(obj.objectId, next);
  }

  function showToast(text) {
    idToast.textContent = text;
    idToast.classList.add("show");
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => idToast.classList.remove("show"), 1800);
  }

  /* ── 档案数据分组 ──
     将 info 按 识别 / 运营 / 能耗 分组，能耗强度按真实最大值计算 */
  const GROUP_OF = {
    "生物识别": "ident", "特征": "ident", "备注": "ident",
    "能源类型": "oper", "核定载客": "oper",
    "制造能耗": "energy", "车辆制造能耗": "energy",
    "制造用水": "energy", "年运营碳排放": "energy",
    "年运营耗电": "energy", "状态": "oper",
  };
  const GROUP_TITLE = {
    ident:  "识别档案 · IDENT",
    oper:   "运营参数 · OPERATION",
    energy: "能耗档案 · ENERGY",
  };

  function renderIdentityTable(obj) { return window.ArchiveData.identity(obj); }

  /* ── 播放控制 ── */
  playBtn.addEventListener("click", () => {
    if (video.paused) video.play();
    else video.pause();
  });

  video.addEventListener("play",  () => (playBtn.textContent = "❚❚"));
  video.addEventListener("pause", () => (playBtn.textContent = "▶"));

  timeline.addEventListener("click", (e) => {
    const rect = timeline.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    video.currentTime = ratio * (video.duration || duration);
  });

  timeline.addEventListener("mousemove", (e) => {
    const rect = timeline.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    timelineTip.style.left = (ratio * 100).toFixed(2) + "%";
    timelineTip.textContent = "00:" + pad(Math.floor(ratio * (video.duration || duration)));
  });

  // 键盘导航：档案打开时左右切换目标，Esc 关闭
  document.addEventListener("keydown", (e) => {
    if (document.getElementById("oaInspectionDialog")?.open) return;
    if (document.getElementById("oaSourceDialog")?.open) return;
    if (acArchiveOpen) {
      if (e.key === "Escape") { e.preventDefault(); closeAcArchive(); }
      return;
    }
    if (objArchiveOpen) {
      if (e.key === "Escape") { e.preventDefault(); closeObjectArchive(); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); goToOrder(-1); }
      else if (e.key === "ArrowRight") { e.preventDefault(); goToOrder(1); }
      return;
    }
  });

  /* ── 空调档案模块（v7 handoff）同源 iframe 集成 ──
     按 README 推荐方式：先显示 iframe 再 open，监听 sp:archive-close 后隐藏 */
  function ensureAcApi() {
    if (acApi) return acApi;
    try {
      const w = acFrame.contentWindow;
      if (w && w.SecondPopulationArchive) {
        acApi = w.SecondPopulationArchive;
        if (!acCloseBound) {
          w.addEventListener("sp:archive-close", closeAcArchive);
          acCloseBound = true;
        }
      }
    } catch (err) { /* 跨域时不可达；本部署为同源 */ }
    return acApi;
  }

  let acPending = false;
  acFrame.addEventListener("load", () => {ensureAcApi();if(acPending && acApi){acPending=false;openAcArchive();}});
  window.addEventListener("message", (e) => {
    if (e.source===acFrame.contentWindow && e.origin===location.origin && e.data && e.data.type === "sp-ready") ensureAcApi();
  });

  function openAcArchive() {
    if(!acFrame.getAttribute("src")) acFrame.src=acFrame.dataset.src;
    const api = ensureAcApi();
    if (!api) { acPending=true;showToast("AC ARCHIVE 模块加载中…"); return; }
    acArchiveOpen = true;
    rememberScene();
    window.Census.setState({view:'archive'});
    acFrame.hidden = false;          // 先可见，画布才能取得正确尺寸
    acFrameClose.hidden = false;
    video.pause();
    document.body.style.overflow = "hidden";
    window.RenderLifecycle.changed();
    requestAnimationFrame(() => {
      try { api.open("SP-0004"); }   // 直接进入旋转加载 → 档案，跳过模块演示空间
      catch (err) { console.error("[AC] open 失败:", err); }
    });
  }

  function closeAcArchive() {
    if (!acArchiveOpen) return;
    acArchiveOpen = false;
    acFrame.hidden = true;
    acFrameClose.hidden = true;
    document.body.style.overflow = "";
    boxEls.forEach((el) => el.classList.remove("show-card", "focused"));
    if (acApi && typeof acApi.close === "function") {
      try { acApi.close(); } catch (err) {}
    }
    acApi=null;acCloseBound=false;acPending=false;acFrame.removeAttribute('src');
    window.Census.setState({view:'monitor'});
    restoreScene();
    window.RenderLifecycle.changed();
  }

  acFrameClose.addEventListener("click", closeAcArchive);

  /* ─────────────────────────────────────────────────────────────
     通用 OBJECT ARCHIVE —— 全屏两段式档案（与空调 v7 同范式）
       阶段一：几何扫描（线网逐级揭示 + 旋转 + 进度条）
       阶段二：档案（实体模型 + 身份表 + 碳记录 + 资源连接，逐块揭示）
     ───────────────────────────────────────────────────────────── */
  const objArchive      = document.getElementById("objArchive");
  const objArchiveClose = document.getElementById("objArchiveClose");
  const oaScan          = document.getElementById("oaScan");
  const oaDossier       = document.getElementById("oaDossier");
  const oaScanShell     = document.getElementById("oaScanShell");
  const oaScanId        = document.getElementById("oaScanId");
  const oaScanStatus    = document.getElementById("oaScanStatus");
  const oaProgressFill  = document.getElementById("oaProgressFill");
  const oaProgressNum   = document.getElementById("oaProgressNum");
  const oaProgressBar   = document.getElementById("oaProgressBar");
  const oaFootnoteId    = document.getElementById("oaFootnoteId");
  const oaSubject       = document.getElementById("oaSubject");
  const oaName          = document.getElementById("oaName");
  const oaNameEn        = document.getElementById("oaNameEn");
  const oaIdentity      = document.getElementById("oaIdentity");
  const oaCarbonValue   = document.getElementById("oaCarbonValue");
  const oaCarbonNote    = document.getElementById("oaCarbonNote");
  const oaResourceUnit  = document.getElementById("oaResourceUnit");
  const oaFooterNote    = document.getElementById("oaFooterNote");
  const oaViewLabel     = document.getElementById("oaViewLabel");
  const oaSolidCanvas   = document.getElementById("oaSolidCanvas");
  const oaWireCanvas    = document.getElementById("oaWireCanvas");
  const oaProfileCanvas = document.getElementById("oaProfileCanvas");
  const oaCrosses       = document.getElementById("oaCrosses");

  const oaEntry = new window.ArchiveEntry(oaDossier, {reduced: window.matchMedia("(prefers-reduced-motion: reduce)").matches});
  let objArchiveOpen = false;
  let oaScanPlayer = null;    // 扫描阶段播放器（线网）
  let oaSolidPlayer = null;   // 档案阶段播放器（实体）
  let oaPhase = "scan";         // scan | dossier
  let oaCurrent = null;         // 当前目标对象
  let oaRevealTimer = null;
  let oaScanRaf = null;
  let oaScanResume=null,oaScanHiddenAt=0;
  document.addEventListener('visibilitychange',()=>{
    if(!objArchiveOpen||oaPhase!=='scan')return;
    if(document.hidden){oaScanHiddenAt=performance.now();cancelAnimationFrame(oaScanRaf);}
    else if(oaScanResume){oaScanResume.shift(performance.now()-oaScanHiddenAt);oaScanRaf=requestAnimationFrame(oaScanResume.step);}
  });

  /* 场景状态记忆：打开档案前记住播放/焦点，关闭时原样恢复（不再强行续播） */
  let sceneState = null;
  function rememberScene() {
    if (!sceneState) sceneState = { sceneId:currentScene,time:video.currentTime,selectedObjectId:selectedId?objects.find(o=>o.objectId===selectedId)?.canonicalId:null,paused: video.paused, focus: document.activeElement, overflow: document.body.style.overflow };
  }
  function restoreScene() {
    const saved = sceneState; sceneState = null;
    document.body.style.overflow = saved?.overflow ?? "";
    if (saved && !saved.paused) video.play().catch(() => {});
    else video.pause();
    if (saved?.focus?.isConnected) saved.focus.focus({ preventScroll: true });
  }

  /* 三维检视弹窗（张娜娜 10/26 新增：可拖拽旋转的真三维视图） */
  const inspection = new window.ArchiveInspection(document.getElementById("oaInspectionDialog"));
  document.getElementById("oaInspect").addEventListener("click", () => {
    if (!oaCurrent || oaPhase !== "dossier") return;
    if (oaSolidPlayer) oaSolidPlayer.stop();
    if (window.ArchiveMotion) window.ArchiveMotion.stop();
    inspection.open(oaCurrent);
  });
  inspection.onClose = () => {
    if (!objArchiveOpen || oaPhase !== "dossier" || !oaCurrent) return;
    oaSolidPlayer?.showSolid(oaCurrent.category, window.ArchiveCatalog.subtype(oaCurrent));
    if(!window.ArchiveCatalog.studyKind(oaCurrent)||oaCurrent.category==='vehicle')window.ArchiveMotion?.start(oaProfileCanvas, oaCurrent);
  };

  if (oaCrosses) oaCrosses.innerHTML = "<span></span>".repeat(20);

  /* 阶段二：档案内容填充 */
  function populateObjectArchive(obj) {
    const A=window.ArchiveData, kind=window.ArchiveCatalog.subtype(obj);
    const profile=window.residentProfile(kind,obj);
    const azhong=kind==='truck' && obj.objectId==='TRK-0002';
    oaSubject.textContent='居民档案 / '+(obj.canonicalId||obj.objectId);
    oaName.textContent=azhong?'阿重':obj.label;
    oaNameEn.textContent=(azhong?'厢式货车 · ':'')+obj.labelEn;
    const structures={van:'高顶车厢 · 滑门导轨 · 轮组',mpv:'乘员舱 · 侧窗 · 轮组',truck:'驾驶室 · 货厢 · 底盘',suv:'车身 · 轮拱 · 底盘',sedan:'乘员舱 · 风挡 · 轮组',bus:'客舱 · 站立区 · 车门',coach:'乘员舱 · 行李舱 · 轮组',banner:'立杆 · 横撑 · 旗面','bike-rack':'车架 · 轮组 · 停放支架'};
    const rows=[['居民编号',obj.canonicalId||obj.objectId],['来源街区',obj.cameraId||window.Census.get(obj.canonicalId)?.cameraId||'街区观察'],['城市角色',profile.role]];
    if(structures[kind])rows.push(['身体结构',structures[kind]]);
    oaIdentity.innerHTML=rows.map(([k,v])=>'<div class="id-row"><dt>'+k+'</dt><dd>'+A.escape(v)+'</dd></div>').join('');
    document.getElementById('oaDescription').textContent=azhong?'「货物我都护好啦。」　温柔、靠谱、有些慢热。喜欢晚霞和驾驶室里的电台。':profile.story;
    oaViewLabel.textContent='结构研究 / 01';
    oaCarbonValue.textContent=profile.value;
    document.getElementById('oaCarbonUnit').textContent=profile.unit;
    oaCarbonNote.textContent=profile.note;
    const link=document.getElementById('energySource');link.hidden=!profile.url;link.href=profile.url||'';link.textContent=profile.source+' ↗';
    document.getElementById('oaCarbonExpression').innerHTML='<svg viewBox="0 0 32 24" width="52" height="39" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 2h20l4 4v12l-4 4H6l-4-4V6z"/><path d="M8 9h4m8 0h4M10 15v2h12v-2"/></g></svg><small>工作神态 · '+profile.mood+'</small>';
    oaResourceUnit.textContent=obj.label;
    const icon=document.querySelector('#objArchive .resource-unit svg'),unit=icon.parentElement;
    unit.querySelector('canvas')?.remove();icon.style.display='';
    if(window.ArchiveCatalog.studyKind(obj)){
      icon.style.display='none';
      const tile=document.createElement('canvas');tile.width=154;tile.height=88;tile.style.cssText='width:77px;height:44px;display:block;margin:auto';unit.prepend(tile);
      const model=window.ModelEngine.buildModel(obj.category,kind);
      window.ArchiveEngineering.render(tile.getContext('2d'),model,{w:154,h:88,pitch:.32,glitch:false});
    }else icon.innerHTML=A.symbol(obj);
    document.getElementById('residentRole').textContent=profile.role;
    oaFooterNote.textContent='居民叙事 / 角色创作';
    document.getElementById('oaInsetOne').textContent=(kind==='streetlight'||(window.ArchiveCatalog.studyKind(obj)&&obj.category!=='vehicle'))?'构造 / STRUCTURE':'轮组 / WHEEL';
    document.getElementById('oaInsetTwo').textContent=(window.ArchiveCatalog.studyKind(obj)&&obj.category!=='vehicle')?'侧视 / PROFILE':'机能 / MOTION STUDY';
    document.getElementById('oaSourceText').textContent='观察编号 '+(obj.canonicalId||obj.objectId)+' · '+obj.label+'。形象为结构示意，独白与神态为角色创作。能耗卡使用同类公开资料。';
  }

  /* 缩略图：线框结构 + 侧影视图（一次性静态渲染） */
  function renderArchiveInsets(obj) {
    if (!window.ModelEngine) return;
    if (window.ArchiveVisuals) { requestAnimationFrame(()=>{ if(oaCurrent!==obj||!objArchiveOpen)return; window.ArchiveVisuals.detail(oaWireCanvas,obj,"wheel");window.ArchiveVisuals.detail(oaProfileCanvas,obj,"assembly"); }); return; }
    const subtype = window.ModelEngine.detectSubtype(obj.category, obj.labelEn);
    const model = window.ModelEngine.buildModel(obj.category, subtype);
    const draw = (canvas, mode, yaw) => {
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const r = canvas.getBoundingClientRect();
      const w = Math.max(1, r.width || 200), h = Math.max(1, r.height || 130);
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      const ctx = canvas.getContext("2d");
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (mode === "wire") {
        window.ModelEngine.renderScan(ctx, model, {
          w: w, h: h, yaw: yaw, time: 0, completion: 1, opacity: 1
        });
      } else {
        window.ModelEngine.renderSolid(ctx, model, { w: w, h: h, yaw: yaw, time: 0 });
      }
    };
    // 等布局稳定后再绘制（canvas 需要真实尺寸）
    requestAnimationFrame(function () {
      draw(oaWireCanvas, "wire", -0.5);
      draw(oaProfileCanvas, "solid", -1.35);
    });
  }

  /* 阶段一：扫描 */
  function runScan(obj) {
    oaPhase = "scan";
    inspection.close();
    if(window.ArchiveMotion)window.ArchiveMotion.stop();
    oaEntry.cancel();
    if(oaScanPlayer)oaScanPlayer.stop();
    if(oaSolidPlayer)oaSolidPlayer.stop();
    if(oaScanRaf)cancelAnimationFrame(oaScanRaf);
    if(oaRevealTimer)clearTimeout(oaRevealTimer);
    oaScan.hidden = false;
    oaDossier.hidden = true;
    oaDossier.classList.remove("is-open", "is-revealing");
    oaScanId.textContent = obj.objectId;
    document.getElementById("oaScanType").textContent=(window.ArchiveCatalog.studyKind(obj)?obj.labelEn:window.ArchiveData.type(obj))+" / 01";
    const subtype=window.ArchiveCatalog.subtype(obj);
    const street=window.ArchiveCatalog.studyKind(obj)&&obj.category!=='vehicle';
    const parts=street?['PROFILE','SURFACE','ASSEMBLY','DETAIL']:obj.category==='person'?['HELMET','RIDER','FRAME','DRIVE']:subtype==='truck'?['CAB','CARGO BODY','CHASSIS','RUNNING GEAR']:obj.category==='infrastructure'?['MAST','ARM','LED ARRAY','BASE']:['BODY','GLAZING','RUNNING GEAR','THERMAL'];
    document.getElementById('oaScanParts').replaceChildren(...parts.map(label=>{const span=document.createElement('span');span.textContent=label;return span;}));
    oaFootnoteId.textContent = obj.objectId;
    oaScanStatus.textContent = "INITIALIZING";
    oaScanShell.style.setProperty('--frame-opacity','0');
    oaScanShell.style.setProperty('--content-opacity','0');
    oaScanShell.style.setProperty('--frame-x','.28');
    oaScanShell.style.setProperty('--frame-y','.02');
    oaProgressFill.style.width = "0%";
    oaProgressNum.textContent = "00%";
    oaProgressBar.setAttribute("aria-valuenow", "0");

    const duration = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 1200 : window.ArchiveSequence.duration;
    let start = performance.now();
    const reduced = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)").matches : false;
    const step = () => {
      if(document.hidden||!objArchiveOpen||oaPhase!=='scan')return;
      const el = performance.now() - start;
      const frame=window.ArchiveSequence.frame(el,duration);
      const prog = frame.progress;
      oaProgressFill.style.width = prog + "%";
      oaProgressNum.textContent = String(prog).padStart(2, "0") + "%";
      oaProgressBar.setAttribute("aria-valuenow", String(prog));
      oaScanStatus.textContent=frame.label;
      oaScanShell.style.setProperty('--frame-opacity',frame.frameOpacity.toFixed(3));
      oaScanShell.style.setProperty('--frame-x',frame.frameX.toFixed(3));
      oaScanShell.style.setProperty('--frame-y',frame.frameY.toFixed(3));
      oaScanShell.style.setProperty('--content-opacity',frame.contentOpacity.toFixed(3));
      if (!frame.done) { oaScanRaf = requestAnimationFrame(step); }
    };
    oaScanResume={step,shift:delta=>{start+=delta}};
    oaScanRaf = requestAnimationFrame(step);

    // 模型动画：线网扫描 → 实体
    if (window.ModelEngine) {
      if (!oaScanPlayer) oaScanPlayer = new window.ModelEngine.Player(document.getElementById("oaModelCanvas"));
      oaScanPlayer.attach(document.getElementById("oaModelCanvas"));
      oaScanPlayer.play(obj.category, window.ArchiveCatalog.subtype(obj), {
        duration: duration,
        started: start,
        onDone: function () { if(oaScanPlayer)oaScanPlayer.stop(); if(objArchiveOpen && oaCurrent===obj)showDossier(obj); }
      });
    } else {
      if (oaRevealTimer) clearTimeout(oaRevealTimer);
      oaRevealTimer = setTimeout(function () { showDossier(obj); }, duration);
    }
  }

  /* 阶段二：档案 */
  function showDossier(obj) {
    oaPhase = "dossier";
    // 停掉扫描播放器：避免其在隐藏画布上继续空转渲染
    if (oaScanPlayer) oaScanPlayer.stop();
    oaScan.hidden = true;
    oaDossier.hidden = false;
    oaDossier.scrollTop=0;
    oaDossier.classList.add("is-revealing");
    populateObjectArchive(obj);
    renderArchiveInsets(obj);
    if(window.ArchiveMotion&&(!window.ArchiveCatalog.studyKind(obj)||obj.category==='vehicle'))requestAnimationFrame(()=>{if(objArchiveOpen&&oaCurrent===obj)window.ArchiveMotion.start(oaProfileCanvas,obj);});
    oaEntry.play();
    window.attachPopulationJourney(oaDossier,obj.canonicalId);
    requestAnimationFrame(function () { if(objArchiveOpen && oaCurrent===obj)oaDossier.classList.add("is-open"); });
    // 实体模型持续渲染（切换到档案阶段的画布）
    if (window.ModelEngine) {
      if (!oaSolidPlayer) oaSolidPlayer = new window.ModelEngine.Player(oaSolidCanvas);
      oaSolidPlayer.attach(oaSolidCanvas);
      oaSolidPlayer.showSolid(obj.category, window.ArchiveCatalog.subtype(obj));
    }
  }

  function openObjectArchive(obj) {
    rememberScene();
    selectedId = obj.objectId;
    oaCurrent = obj;
    boxEls.forEach((el, id) => el.classList.toggle("selected", id === obj.objectId));
    listEls.forEach((el, id) => el.classList.toggle("selected", id === obj.objectId));
    if (Panels.library && Panels.library.markActive) Panels.library.markActive(obj.objectId);
    showToast("objectId → " + obj.objectId);

    objArchiveOpen = true;
    window.Census.setState({view:'archive',selectedObjectId:obj.canonicalId,currentTime:video.currentTime});
    window.Census.emit('archiveopen',{canonicalId:obj.canonicalId,sceneId:currentScene});
    window.RenderLifecycle.changed();
    objArchive.hidden = false;
    objArchive.setAttribute("aria-hidden","false");
    document.body.style.overflow = "hidden";
    video.pause();
    runScan(obj);
  }

  function closeObjectArchive(options={}) {
    if (!objArchiveOpen) return;
    objArchiveOpen = false;
    inspection.close();
    if (document.getElementById('oaSourceDialog').open) document.getElementById('oaSourceDialog').close();
    if(window.ArchiveMotion)window.ArchiveMotion.stop();
    objArchive.hidden = true;
    objArchive.setAttribute("aria-hidden","true");
    oaEntry.cancel();
    document.body.style.overflow = "";
    boxEls.forEach((el) => el.classList.remove("show-card", "focused"));
    if (oaScanPlayer) oaScanPlayer.stop();
    if (oaSolidPlayer) oaSolidPlayer.stop();
    if (oaScanRaf) cancelAnimationFrame(oaScanRaf);
    if (oaRevealTimer) clearTimeout(oaRevealTimer);
    if (Panels.library && Panels.library.markActive) Panels.library.markActive(null);
    if(options.resume===false){sceneState=null;video.pause();}else{window.Census.setState({view:'monitor'});restoreScene();}
    window.Census.emit('archiveclose',{canonicalId:oaCurrent?.canonicalId,suppressed:options.resume===false});
    window.RenderLifecycle.changed();
  }

  objArchiveClose.addEventListener("click", closeObjectArchive);
  const oaBack = document.getElementById("oaBackToScene");
  if (oaBack) oaBack.addEventListener("click", closeObjectArchive);
  const oaPrevBtn = document.getElementById("oaPrev");
  const oaNextBtn = document.getElementById("oaNext");
  if (oaPrevBtn) oaPrevBtn.addEventListener("click", function (e) { e.stopPropagation(); goToOrder(-1); });
  if (oaNextBtn) oaNextBtn.addEventListener("click", function (e) { e.stopPropagation(); goToOrder(1); });
  const oaReplay = document.getElementById("oaReplay");
  if (oaReplay) oaReplay.addEventListener("click", function () {
    if (oaCurrent) runScan(oaCurrent);
  });

  document.getElementById('oaSource').addEventListener('click',()=>document.getElementById('oaSourceDialog').showModal());
  document.getElementById('oaSourceClose').addEventListener('click',()=>document.getElementById('oaSourceDialog').close());
  window.addEventListener('resize',()=>{if(!objArchiveOpen)return;if(oaPhase==='scan'&&oaScanPlayer)oaScanPlayer.resize();if(oaPhase==='dossier'){if(oaSolidPlayer)oaSolidPlayer.resize();renderArchiveInsets(oaCurrent);}});

  /* ── 数字滚动动画 ── */
  const shown = { objects: 0, energy: 0, water: 0, persons: 0 };
  function tickNumber(el, key, target) {
    if (shown[key] === target) return;
    shown[key] += (target - shown[key]) * 0.12;
    if (Math.abs(target - shown[key]) < 1) shown[key] = target;
    el.textContent = Math.round(shown[key]).toLocaleString("en-US");
  }

  /* ── 时间码格式化 ── */
  function pad(n) { return String(n).padStart(2, "0"); }
  function fmtTC(t) {
    return pad(Math.floor(t / 60)) + ":" + pad(Math.floor(t % 60)) + ":" + pad(Math.floor((t % 1) * 25));
  }

  /* ── 主渲染循环 ── */
  let lastDraw = 0;
  function renderFrame(time) {
    // 帧间 dt（用于缓动）
    if (!lastT) lastT = time;
    const dt = Math.min(0.05, (time - lastT) / 1000);
    lastT = time;
    // 限到 ~30fps：识别框位移极慢，不必每帧全量重写 DOM（省主线程，保证点击响应）
    if (time - lastDraw < 33) return;
    lastDraw = time;

    const t = video.currentTime;

    // 框层尺寸对齐（尺寸变化时才重算）
    // 指纹里必须带上 videoWidth：视频元数据晚到时 applyFit 会提前 return，
    // 若指纹只看 clientWidth，letterbox 校准就永远不会再执行，整屏框会错位
    const mainSize = video.clientWidth + "x" + video.clientHeight + "@" + (video.videoWidth || 0);
    if (mainSize !== lastMainSize || !layerW || !layerH) {
      applyFit(video, mainLayer, "contain");
      lastMainSize = mainSize;
      layerW = mainLayer.clientWidth; layerH = mainLayer.clientHeight; // 仅此一次同步布局
      if (!layerW || !layerH) {
        // 兜底：元素处于未布局 / 隐藏状态时 clientWidth 为 0，改用 rect 量一次
        const r = mainLayer.getBoundingClientRect();
        layerW = r.width; layerH = r.height;
      }
    }

    // 时间轴与时间码
    const d = video.duration || duration;
    timelineFill.style.width = ((t / d) * 100).toFixed(2) + "%";
    timelineHandle.style.left = ((t / d) * 100).toFixed(2) + "%";
    timecode.textContent = "00:" + pad(Math.floor(t)) + " / 00:" + pad(Math.floor(d));
    recTime.textContent = "REC 00:" + fmtTC(t);
    hudClock.textContent = "T+" + t.toFixed(2) + "s";

    // 识别框跟随（presence 缓动：出现/消失不再硬切）
    let onscreen = 0, energy = 0, water = 0, persons = 0;
    const lockedNow = [];
    objects.forEach((obj) => {
      const el = boxEls.get(obj.objectId);
      const li = listEls.get(obj.objectId);
      const visible = t >= obj.appear && t <= obj.disappear;

      // presence 0→1（入场）/ 1→0（离场）缓动
      const target = visible ? 1 : 0;
      if (obj._pres == null) obj._pres = 0;
      obj._pres += (target - obj._pres) * Math.min(1, dt * 9);
      if (!visible && obj._pres < 0.012) {
        if (el.style.display !== "none") el.style.display = "none";
        li.classList.remove("onscreen");
        obj._logged = false;
        return; // 完全离场，跳过后续更新
      }
      if (el.style.display === "none") el.style.display = "block";

      if (visible) {
        onscreen++;
        const b = interpolate(obj.keyframes, t);
        // 位置改走 GPU 合成（transform:translate），不再写 left/top —— 消除每帧 layout 重排（卡顿主因）
        if (layerW && layerH) {
          obj._tx = Math.round(b.x * layerW * 100) / 100;
          obj._ty = Math.round(b.y * layerH * 100) / 100;
          obj._bw = b.w * layerW;
        }
        // 尺寸仍用 %（bbox 宽高变化少，dirty-check 命中即跳过）
        const W = (b.w * 100).toFixed(3) + "%";
        const H = (b.h * 100).toFixed(3) + "%";
        if (obj._W !== W) { el.style.width = W; obj._W = W; }
        if (obj._H !== H) { el.style.height = H; obj._H = H; }
        // 锁定进度条：目标出现后 1.2s 内填满 → 模拟识别锁定过程
        const lock = lockEls.get(obj.objectId);
        const lockPct = Math.min(100, ((t - obj.appear) / 1.2) * 100);
        if (lock && obj._lock !== lockPct) { lock.style.width = lockPct + "%"; obj._lock = lockPct; }
        li.classList.add("onscreen");
        // 刚刚完成锁定 → 推送到实时代码面板
        if (lockPct >= 100 && !obj._logged) {
          obj._logged = true;
          lockedNow.push(obj);
        }
      }

      // presence → 透明度；位移+缩放合并为一次 transform 写入（composite-only，不触发重排）
      const op = obj._pres.toFixed(3);
      if (obj._op !== op) { el.style.opacity = op; obj._op = op; }
      const sc = (0.90 + 0.10 * obj._pres).toFixed(3);
      const tf = "translate(" + (obj._tx || 0) + "px," + (obj._ty || 0) + "px) scale(" + sc + ")";
      if (obj._tf !== tf) { el.style.transform = tf; obj._tf = tf; }

      // 贴边的框：标签 / 左侧标尺翻向内侧，避免被 .viewport 的 overflow:hidden 整条裁掉
      const tx = obj._tx || 0, ty = obj._ty || 0, bw = obj._bw || 0;
      const tagIn = ty < 22;
      if (obj._tagIn !== tagIn) { el.classList.toggle("tag-in", tagIn); obj._tagIn = tagIn; }
      const rulerIn = tx < 20;
      if (obj._rulerIn !== rulerIn) { el.classList.toggle("ruler-in", rulerIn); obj._rulerIn = rulerIn; }
      const tagR = !tagIn && layerW > 0 && tx + bw > layerW - 108;
      if (obj._tagR !== tagR) { el.classList.toggle("tag-r", tagR); obj._tagR = tagR; }

      // 累计统计：已出现过的目标计入普查
      if (t >= obj.appear) {
        energy += obj.energyKwh;
        if (obj.category === "person") persons++;
        const w = obj.info["制造用水"];
        if (w) water += parseFloat(w.replace(/[^0-9.]/g, "")) || 0;
      }
    });

    // The visible code panel consumes canonical discovery/frame events in monitor-layout.js.

    detectCount.textContent = pad(onscreen);

    // 右侧目标蛛网：随识别进度点亮点位（内部脏检查，开销极小）
    if (window.ObjectWeb) window.ObjectWeb.tick(t);
    window.Census.emit("frame",{sceneId:currentScene,time:t,duration:d,visibleIds:objects.filter(o=>t>=o.appear&&t<=o.disappear).map(o=>o.canonicalId)});
    for(const obj of objects){if(t>=obj.appear&&!discoveredIds.has(obj.canonicalId)){discoveredIds.add(obj.canonicalId);window.Census.emit('objectdiscovered',{canonicalId:obj.canonicalId,sceneId:currentScene,category:obj.category,color:obj.color,object:obj});}}

    // 识别跟踪进度：已出现目标数 / 总目标数
    const identified = objects.filter((o) => t >= o.appear).length;
    const pct = Math.round((identified / objects.length) * 100);
    tpPct.textContent = pct + "%";
    tpBar.style.width = pct + "%";
    tpCount.textContent = String(identified).padStart(2, "0");

    tickNumber(statObjects, "objects", identified);


    tickNumber(statPersons, "persons", persons);

    const identifiedObjects=objects.filter(o=>t>=o.appear&&o.populationEligible!==false);
    tickNumber(statEnergy,"energy",identifiedObjects.reduce((a,o)=>a+(o.energyKwh||0),0));
    tickNumber(statWater,"water",identifiedObjects.reduce((a,o)=>a+(parseFloat(String(o.info?.['制造用水']||'').replace(/,/g,''))||0),0));
    // 3D 群像面板：喂入已识别的目标（仅原版场景；低频更新，避免每帧重建）
    if (document.body.classList.contains("on-legacy") && (!renderFrame._crowdAt || time - renderFrame._crowdAt > 700)) {
      renderFrame._crowdAt = time;
      const seen = objects.filter((o) => t >= o.appear);
      if (Panels.crowd && Panels.crowd.update) Panels.crowd.update(seen);
    }
  }

  /* 包装层：单帧内的任何异常都不得中断识别循环。
     过去只要一帧抛错，requestAnimationFrame 就不再续订，整屏识别框与标签会静止/消失。 */
  function render(time) {
    try {
      renderFrame(time);
    } catch (err) {
      if (!render._logged) { render._logged = 1; console.error("[TRACKER] 渲染帧异常（已忽略并继续）:", err); }
    }
  }

  video.addEventListener("loadedmetadata", () => {
    lastMainSize = "";
    if (!objArchiveOpen && !acArchiveOpen && window.RenderLifecycle.stageVisible()) video.play().catch(() => { playBtn.textContent = "▶"; });
  });

  window.addEventListener("resize", () => {
    lastMainSize = "";
  });

  /* ─────────────────────────────────────────────────────────────
     场景切换（Street 01–04）
     - street1–4 使用 B 的原始采样，legacy 单独保留 A 的旧片段。
     - 所有对象共用档案入口，已有模型族进入扫描，其余显示来源取证档案。
     ───────────────────────────────────────────────────────────── */
  async function loadScene(key) {
    const scene = SCENES[key];
    if (!scene) return;
    if (currentScene === key) return scenePromise;
    if(acPending){acPending=false;acApi=null;acCloseBound=false;acFrame.removeAttribute('src');}
    currentScene = key;
    const token = ++loadToken;

    // 切换场景时若档案 / 空调模块仍打开，先收起，避免残留在新场景之上
    if (objArchiveOpen) closeObjectArchive();
    if (acArchiveOpen) closeAcArchive();

    // 导航高亮
    if (sceneNav) {
      sceneNav.querySelectorAll(".scene").forEach((b) => {
        b.classList.toggle("active", b.dataset.scene === key);
      });
    }

    // 切换视频源
    if (video.getAttribute("src") !== scene.video) {
      video.src = scene.video;
      video.load();
    }

    // Legacy lower panels stay attached to their original take; archives work across scenes.
    document.body.classList.toggle("on-legacy", key === "legacy");

    // 更新 HUD 摄像机 / 区域 / 帧率
    if (camLabel) camLabel.textContent = scene.cam;
    if (zoneLabel) zoneLabel.textContent = scene.zone;
    if (hudFps) hudFps.textContent = "TRACKING @ " + scene.fps + " FPS";

    scenePromise = window.Census.scene(key)
      .then(async (data) => {
        if (token !== loadToken) return; // 已被更新的切换覆盖，丢弃旧结果
        objects = Array.isArray(data) ? data : (data.objects || []);
        discoveredIds=new Set();
        duration = (data && data.duration) || (video.duration || 30);
        maxEnergy = objects.reduce((m, o) => Math.max(m, o.energyKwh || 0), 1);

        // 识别框 / 清单 / 标签必须先于任何异步依赖生成：
        // 档案文案层只是文字补充，绝不能阻塞「实时识别」这一主功能
        buildSceneUI();
        window.Census.emit("scenechange",{sceneId:key,scene:SCENES[key],objects});
        window.RenderLifecycle.changed();

        // 档案文案层（张娜娜 10/26）：records.json 可编辑文字，与识别坐标分离
        if (key === "legacy" && window.ArchiveCatalog && typeof window.ArchiveCatalog.load === "function") {
          try { await window.ArchiveCatalog.load(objects); }
          catch (e) { console.warn("[ARCHIVE] records 不可用，沿用目标原始标注", e); }
        }
        if (token !== loadToken) return;

        // 预热取证缩略图：场景载入即把图片拉进浏览器缓存，悬停/选中时即时显示，
        // 避免播放中现场请求导致卡顿或短暂加载不出来
        // Card images already own their requests; do not preload them a second time.

        if (key === "legacy") {
          if (Panels.library && Panels.library.build) Panels.library.build(objects);
          showToast("已载入 " + objects.length + " 条观察记录 · 点击目标调档");
        } else {
          if (Panels.library && Panels.library.build) Panels.library.build([]);
          showToast("已载入 " + scene.cam + " · " + objects.length + " 条观察记录");
        }
      })
      .catch((err) => {
        console.error("[loadScene] 加载失败:", err);
        showToast("场景加载失败：" + scene.tracks);
      });
    return scenePromise;
  }

  /* 档案库卡片点击：复用闭包中的 objects（始终指向当前场景） */
  const libTrackEl = document.getElementById("libTrack");
  if (libTrackEl) {
    libTrackEl.addEventListener("click", (e) => {
      const card = e.target.closest(".lib-card");
      if (!card) return;
      const obj = objects.find((o) => o.objectId === card.dataset.id);
      if (!obj) return;
      if (obj.isAc) { openAcArchive(); return; }   // 空调：走 v7 专用模块
      const maxT = video.duration || duration;
      video.currentTime = Math.min(maxT, obj.appear + 0.1);
      selectObject(obj.objectId);
    });
  }

  /* 场景导航点击 */
  if (sceneNav) {
    sceneNav.addEventListener("click", (e) => {
      const btn = e.target.closest(".scene");
      if (!btn) return;
      const key = btn.dataset.scene;
      if (key === currentScene) return;
      loadScene(key);
    });
  }

  /* 供右栏「目标蛛网」的监控卡片使用：切换场景 / 读取当前场景 */
  window.__switchScene = function (key) { return loadScene(key); };
  window.__openCanonical = async function(id,options={}){const record=window.Census.get(id);if(!record)return;await loadScene(record.sceneId);await ensureVideoReady();const saved=options.returnSnapshot;video.currentTime=Math.min(saved?.time??record.appear+.05,video.duration-.01);selectObject(record.sourceId,undefined,saved);if(saved&&sceneState)sceneState={...sceneState,...saved};};
  window.__activeScene = function () { return currentScene; };
  function ensureVideoReady(){if(video.readyState>=1)return Promise.resolve();return new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{cleanup();reject(Error('Video metadata timeout'));},10000);const cleanup=()=>{clearTimeout(timeout);video.removeEventListener('loadedmetadata',done);video.removeEventListener('error',fail)};const done=()=>{cleanup();resolve()};const fail=()=>{cleanup();reject(Error('Video failed'))};video.addEventListener('loadedmetadata',done,{once:true});video.addEventListener('error',fail,{once:true});});}
  window.Monitor={
    snapshot(){const saved=sceneState;return {sceneId:saved?.sceneId||currentScene,time:saved?.time??video.currentTime,paused:saved?.paused??video.paused,selectedObjectId:saved?.selectedObjectId||(selectedId?objects.find(o=>o.objectId===selectedId)?.canonicalId:null)}} ,
    closeArchive(options={}){closeObjectArchive(options);if(acArchiveOpen)closeAcArchive();},
    async restore(snapshot){if(!snapshot)return;await loadScene(snapshot.sceneId);await ensureVideoReady();video.pause();video.currentTime=Math.max(0,Math.min(snapshot.time,video.duration-.01));selectedId=objects.find(o=>o.canonicalId===snapshot.selectedObjectId)?.objectId||null;focusId=selectedId;boxEls.forEach((el,id)=>el.classList.toggle('selected',id===selectedId));listEls.forEach((el,id)=>el.classList.toggle('selected',id===selectedId));window.Census.setState({view:'monitor',camera:currentScene,cameraId:currentScene==='legacy'?null:'CAM0'+currentScene.slice(-1),currentTime:video.currentTime,paused:snapshot.paused,selectedObjectId:snapshot.selectedObjectId});window.RenderLifecycle.changed();if(!snapshot.paused)video.play().catch(()=>{});}
  };
  for(const event of ['play','pause','seeked'])video.addEventListener(event,()=>{if(window.Census.state.view==='monitor')window.Census.setState({currentTime:video.currentTime,paused:video.paused},false)});

  window.RenderLifecycle.loop("tracking", render, window.RenderLifecycle.stageVisible);

  /* Default capture: B STREET 02. The scene picker appears after ENTER. */
  loadScene("street2");

  /* 兜底自检：若 4s 后画面上仍没有任何识别框（数据晚到 / 首帧异常），
     自动重跑一次场景载入，保证「实时识别」这一主功能不会静默失效 */
  setTimeout(function () {
    if (document.querySelectorAll(".track-box").length) return;
    console.warn("[TRACKER] 识别层未生成，自动重试载入场景");
    currentScene = null;
    loadScene("street2");
  }, 4000);
})();
