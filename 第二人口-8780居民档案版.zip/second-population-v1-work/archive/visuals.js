(function(){'use strict';
 const hash=n=>{const a=Math.sin(n*127.1+311.7)*43758.5453;return a-Math.floor(a);};
 function render(ctx,m,o){if(m.streetStudy||['van','mpv'].includes(m.archiveKind)){window.ArchiveEngineering.render(ctx,m,{...o,yaw:-.66,pitch:m.size.h<m.size.d*.3?.52:.18,glitch:false});return;}if(window.ArchiveScans&&window.ArchiveScans.draw(ctx,window.ArchiveScans.keyFor(m),'main',o.w,o.h,{time:o.time,motion:typeof o.time==='number'}))return;const w=o.w,h=o.h,yaw=o.yaw??-.62,pitch=.2,dist=Math.max(9,m.size.w*1.65),scale=Math.min(w*.8/Math.max(m.size.w,m.size.d),h*.7/m.size.h),cx=w/2,cy=h*.55;const P=p=>{const q=Cam.rotate(p,yaw,pitch),f=dist/(dist-q[2]);return[cx+q[0]*scale*f,cy-q[1]*scale*f,q[2]];};ctx.clearRect(0,0,w,h);ctx.save();
 const faces=m.faces.map(f=>{const q=f.p.map(p=>Cam.rotate(p,yaw,pitch)),center=q[0].map((_,i)=>q.reduce((s,p)=>s+p[i],0)/q.length),n=f.n?Cam.rotate(f.n,yaw,pitch):[0,0,1];return{f,q,n,center};}).filter(a=>a.n[0]*-a.center[0]+a.n[1]*-a.center[1]+a.n[2]*(dist-a.center[2])>0).sort((a,b)=>a.center[2]-b.center[2]);
 const line=(pts)=>{ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();};
 faces.forEach((a,index)=>{const pts=a.f.p.map(P),light=.34+Math.max(0,a.n[0]*-.3+a.n[1]*.6+a.n[2]*.7)*.55;line(pts);const g=ctx.createLinearGradient(pts[0][0],pts[0][1],pts[2][0],pts[2][1]);const glass=a.f.c[0]<18;g.addColorStop(0,glass?'#071014':`rgba(168,211,224,${light*.3})`);g.addColorStop(1,glass?'#020607':`rgba(168,211,224,${light*.07})`);ctx.fillStyle=glass?'#03080a':'#061014';ctx.fill();ctx.fillStyle=g;ctx.fill();ctx.strokeStyle=`rgba(168,211,224,${glass?.48:.24+light*.35})`;ctx.lineWidth=.6;ctx.stroke();
 if(a.f.p.length===4){for(let j=0;j<13;j++){const u=hash(index*19+j*3),v=hash(index*31+j*7),p=a.f.p[0].map((_,k)=>(1-v)*((1-u)*a.f.p[0][k]+u*a.f.p[1][k])+v*((1-u)*a.f.p[3][k]+u*a.f.p[2][k])),s=P(p);ctx.fillStyle=`rgba(168,211,224,${glass?.08:.22+light*.23})`;ctx.fillRect(Math.round(s[0]),Math.round(s[1]),1,1);}}
 });
 ctx.globalCompositeOperation='screen';ctx.lineWidth=.65;for(const e of m.edges){const mid=e.a.map((v,i)=>(v+e.b[i])/2),q=Cam.rotate(mid,yaw,pitch);if(q[2]<-m.size.d*.25)continue;const a=P(e.a),b=P(e.b);ctx.strokeStyle=`rgba(168,211,224,${e.w>.8?.66:.27})`;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();}
 // Sparse edge fragments echo the acquired AC portrait without replacing the object.
 for(let i=0;i<Math.min(95,m.edges.length);i++){const e=m.edges[(i*17)%m.edges.length],p=P(e.a);if(hash(i*7)>.38)continue;ctx.fillStyle='rgba(168,211,224,.27)';const offset=hash(i*13)*8;ctx.fillRect(p[0]+offset,p[1],hash(i*11)*4+1,1);}
 ctx.restore();}
 function detail(canvas,obj,kind){
 const family=window.ArchiveCatalog.studyKind(obj);
 if(family&&obj.category!=='vehicle'){
   const model=window.ModelEngine.buildModel(obj.category,family),r=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,1.5),ctx=canvas.getContext('2d');
   canvas.width=Math.max(1,r.width*dpr);canvas.height=Math.max(1,r.height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);
   window.ArchiveEngineering.render(ctx,model,{w:r.width,h:r.height,yaw:kind==='wheel'?-.35:1.12,pitch:kind==='wheel'?.68:.18,glitch:false});return;
 }
 if(family&&kind==='wheel'){window.ArchiveMechanisms.wheel(canvas,obj);return;}
 if(window.ArchiveScans&&window.ArchiveScans.detail(canvas,obj,kind))return;if(window.ArchiveMechanisms){if(kind==='wheel')window.ArchiveMechanisms.wheel(canvas,obj);else window.ArchiveMechanisms.render(canvas,obj,0);return;}const m=window.ModelEngine.buildModel(obj.category,window.ModelEngine.detectSubtype(obj.category,obj.labelEn)),ctx=canvas.getContext('2d'),r=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,1.5),w=Math.max(1,r.width),h=Math.max(1,r.height);canvas.width=w*dpr;canvas.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);ctx.strokeStyle='#A8D3E0';ctx.fillStyle='rgba(168,211,224,.12)';ctx.lineWidth=.7;
 const x=w*.48,y=h*.51,radius=Math.min(w*.26,h*.39);if(kind==='wheel'){for(const k of [1,.94,.77,.72,.22]){ctx.beginPath();ctx.arc(x,y,radius*k,0,Math.PI*2);ctx.stroke();}for(let i=0;i<20;i++){const a=i/20*Math.PI*2;ctx.beginPath();ctx.moveTo(x+Math.cos(a)*radius*.22,y+Math.sin(a)*radius*.22);ctx.lineTo(x+Math.cos(a+.09)*radius*.72,y+Math.sin(a+.09)*radius*.72);ctx.stroke();}for(let i=0;i<48;i++){const a=i/48*Math.PI*2;ctx.beginPath();ctx.moveTo(x+Math.cos(a)*radius*.95,y+Math.sin(a)*radius*.95);ctx.lineTo(x+Math.cos(a+.015)*radius,y+Math.sin(a+.015)*radius);ctx.stroke();}}
 else{const bx=w*.18,by=h*.2,bw=w*.6,bh=h*.58;ctx.strokeRect(bx,by,bw,bh);for(let i=1;i<13;i++){const xx=bx+i*bw/13;ctx.beginPath();ctx.moveTo(xx,by+5);ctx.lineTo(xx,by+bh-5);ctx.stroke();}ctx.strokeRect(bx+bw*.15,by+bh,bw*.2,4);ctx.strokeRect(bx+bw*.65,by+bh,bw*.2,4);for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(bx+bw,by+10+i*9);ctx.lineTo(bx+bw+10,by+10+i*9);ctx.lineTo(bx+bw+10,by+bh+8);ctx.stroke();}}
 ctx.fillStyle='rgba(168,211,224,.55)';ctx.font='11px monospace';ctx.fillText(kind==='wheel'?'WHEEL / CONSTRUCTION':'ILLUSTRATIVE ASSEMBLY',9,h-7);
 }
 window.ArchiveVisuals={render,detail};
})();
