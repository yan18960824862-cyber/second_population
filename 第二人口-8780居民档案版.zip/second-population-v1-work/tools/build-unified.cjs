/* Reproducible integration. Source annotations are observations, not verified identities. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const context={window:{}};vm.runInNewContext(fs.readFileSync(path.join(root,'street_census/nebula/catalogue.js'),'utf8'),context);
const b=context.window.CATALOGUE,archive=read('archive/records.json').records;
const rules=require('../integration/visual-rules.js');
const number=text=>Number(String(text??'').match(/-?[\d][\d,.]*/)?.[0].replaceAll(',','')||0);
function skyFor(o,duration,scene){
 const k=o.keyframes,t=(o.appear+o.disappear)/2;let a=k[0],z=k.at(-1),ratio=0;
 if(t<=a.t)z=a;else if(t>=z.t)a=z;else for(let i=0;i<k.length-1;i++)if(k[i].t<=t&&k[i+1].t>=t){a=k[i];z=k[i+1];ratio=(t-a.t)/(z.t-a.t||1);break}
 const lerp=key=>a[key]+(z[key]-a[key])*ratio,traj=k.map(k=>[k.x+k.w/2,k.y+k.h/2]);
 const disp=traj.slice(1).reduce((sum,p,i)=>sum+Math.hypot(p[0]-traj[i][0],p[1]-traj[i][1]),0);
 return {...o,scene,categoryLabel:{vehicle:'车流主体',person:'骑手 / 行人',industrial:'工业物',infrastructure:'基底设施'}[o.category]||o.category,t0:o.appear/duration,t1:o.disappear/duration,waterT:number(o.info?.['制造用水']),steelKg:number(o.info?.['用钢量']),lifeYear:number(o.info?.['设计寿命']),carbonT:number(o.info?.['年运营碳排放']),cx:lerp('x')+lerp('w')/2,cy:lerp('y')+lerp('h')/2,area:k[0].w*k[0].h,disp,moving:disp>.02,traj,thumb:'site/thumbs/'+o.objectId+'.jpg'};
}
const scenes=b.scenes.map(s=>({...s,sceneId:s.key,video:'street_census/site/'+s.video,sourceFile:'street_census/site/'+s.tracks,sourceRange:s.key==='street2'?[15,45]:null}));
const records=[],crosswalk=[],matches=[];
for(const scene of scenes){
 const source=read(scene.sourceFile);scene.duration=source.duration;
 for(const o of source.objects){
  const sky=skyFor(o,source.duration,scene.key),canonicalId='SP-'+o.objectId;
  const aliases=[{project:'B',sceneId:scene.key,sourceId:o.objectId}];
  if(scene.key!=='street2'){
   const afile=scene.tracks,ao=read(afile).objects.find(x=>x.objectId===o.objectId);
   assert.deepEqual(ao,o,'Shared observation differs: '+o.objectId);
   aliases.push({project:'A',sceneId:scene.key,sourceId:o.objectId});
   matches.push({canonicalId,sourceIds:[o.objectId],method:'exact-scene-id-and-complete-record',status:'confirmed-same-observation'});
  }
  records.push({canonicalId,sourceId:o.objectId,sourceIds:aliases,sceneId:scene.key,label:o.label,category:o.category,appear:o.appear,disappear:o.disappear,tracking:o.keyframes,trajectory:o.keyframes.map(k=>({t:k.t,x:k.x+k.w/2,y:k.y+k.h/2})),thumb:'street_census/'+sky.thumb,archive:null,resourceData:{status:'unverified-estimate',verifiedValues:[],sources:[],originalEstimates:{energyKwh:o.energyKwh,info:o.info},note:'Original annotations; no measurement, inventory or factor supplied.'},annotation:o,sky:{...sky,objectId:canonicalId,sourceId:o.objectId,canonicalId,thumb:'street_census/'+sky.thumb},provenance:{sourceFile:scene.sourceFile,sourceRange:scene.sourceRange,physicalIdentity:'unresolved'}});
 }
}
const legacy=read('tracks.json');
scenes.push({key:'legacy',sceneId:'street2',alias:'原始档案片段',cam:'CAM 02 / ARCHIVE TAKE',zone:'ZONE B · 原始档案片段 · 77–107s',video:'traffic_clip.mp4',sourceFile:'tracks.json',sourceRange:[77,107],duration:legacy.duration,fps:25,count:legacy.objects.length});
for(const o of legacy.objects){
 records.push({canonicalId:'SP-LEGACY-'+o.objectId,sourceId:o.objectId,sourceIds:[{project:'A',sceneId:'legacy',sourceId:o.objectId}],sceneId:'legacy',parentSceneId:'street2',label:o.label,category:o.category,appear:o.appear,disappear:o.disappear,tracking:o.keyframes,trajectory:o.keyframes.map(k=>({t:k.t,x:k.x+k.w/2,y:k.y+k.h/2})),thumb:'thumbs/'+o.objectId+'.jpg',archive:archive.find(r=>r.objectId===o.objectId)||null,resourceData:{status:'unverified-estimate',verifiedValues:[],sources:[],originalEstimates:{energyKwh:o.energyKwh,info:o.info},note:'Legacy simulated estimates; no verified physical identity across takes.'},annotation:o,provenance:{sourceFile:'tracks.json',sourceVideo:legacy.source,sourceRange:[77,107],physicalIdentity:'unresolved'}});
}
for(const r of records){
 const o=r.annotation,sourceFile=r.provenance.sourceFile,categoryLabel={vehicle:'车流主体',industrial:'工业物',infrastructure:'基底设施',person:'骑手 / 行人',appliance:'独立设备'}[r.category]||r.category;
 const exclusion=o.isAc?'independent-depth-experience':r.category==='person'?'human-or-rider-context':/TREE|SHRUB|HEDGE|ANIMAL|DOG|CAT\b/.test(o.labelEn)?'natural-or-animal-context':null;
 r.labelEn=o.labelEn;r.categoryLabel=categoryLabel;r.keyframes=r.tracking;r.confidence=o.conf;r.source={...r.provenance,project:r.sceneId==='legacy'?'A':'B',sourceId:r.sourceId};
 r.cameraId=r.sceneId==='legacy'?null:'CAM0'+r.sceneId.slice(-1);
 r.timeRange={start:r.appear,end:r.disappear,unit:'s',reference:'source-video'};
 r.categoryOriginal=r.category;
 r.populationEligible=exclusion?false:null;r.populationEligibility={status:exclusion?'excluded':'pending-review',reason:exclusion||'Anthropogenic candidate; individual physical identity and census eligibility need review.'};
 r.eligibilityStatus=r.populationEligibility.status;
 r.auditEvidence={annotationFile:sourceFile,sourceId:r.sourceId,thumbnail:r.thumb,physicalIdentity:'unresolved',independentVerification:false};
 r.modelStatus=o.isAc?'independent-depth-experience':(['vehicle','person','appliance'].includes(o.category)||/LUMINAIRE|STREETLIGHT/.test(o.labelEn)?'illustrative-model':'evidence-only');
 r.resourceVerificationStatus='unverified';
 r.archive=r.archive||{status:'annotation-only',label:r.label,modelStatus:'illustrative-or-unavailable'};
 const group=rules.groups[rules.groupIndex(o)];r.visualGroupId=group.id;r.color=group.color;r.colorRgb=group.color.slice(1).match(/../g).map(v=>parseInt(v,16)).join(',');
 const measure=(value,unit,field)=>({value,unit,status:'simulated-estimate',source:{kind:'project-annotation',path:sourceFile,sourceId:r.sourceId,field},verification:'no-independent-evidence'});
 r.resourceData.sources=[{kind:'project-annotation',path:sourceFile,sourceId:r.sourceId,measurement:false}];
 r.resourceData.quantities={manufacturingEnergy:measure(o.energyKwh,'kWh','energyKwh'),manufacturingWater:measure(o.info?.['制造用水']?number(o.info['制造用水']):null,'t','info.制造用水'),steel:measure(o.info?.['用钢量']?number(o.info['用钢量']):null,'kg','info.用钢量'),designLife:measure(o.info?.['设计寿命']?number(o.info['设计寿命']):null,'year','info.设计寿命'),annualCarbon:measure(o.info?.['年运营碳排放']?number(o.info['年运营碳排放']):null,'t CO₂e/year','info.年运营碳排放')};
 if(r.sky)Object.assign(r.sky,{visualGroupId:r.visualGroupId,color:r.color,colorRgb:r.colorRgb,populationEligible:r.populationEligible,source:r.source});
 for(const a of r.sourceIds)crosswalk.push({...a,canonicalId:r.canonicalId});
}
const unmatched=records.filter(r=>r.sceneId==='legacy').map(r=>({canonicalId:r.canonicalId,status:'unresolved',reason:'Different non-overlapping capture interval; label/category alone do not establish identity.',candidates:records.filter(b=>b.sceneId==='street2'&&b.category===r.category&&b.label===r.label).map(b=>b.canonicalId)}));
assert.equal(b.objects.length,75);assert.equal(matches.length,54);assert.equal(new Set(records.map(r=>r.canonicalId)).size,records.length);
const payload={version:1,summary:{originalBRecords:75,legacyARecords:40,sharedObservations:54,observationRecords:records.length,uniquePhysicalObjects:null,verifiedPopulationCount:null,eligibilityReview:'pending',originalBCategories:{vehicle:40,industrial:15,infrastructure:13,person:7}},visualRules:rules.groups,scenes,records};
fs.mkdirSync(path.join(root,'data'),{recursive:true});
for(const [file,data]of Object.entries({'census.json':payload,'id-crosswalk.json':crosswalk,'matching-report.json':{confirmed:matches,unresolved:unmatched,policy:'Never merge across capture intervals without physical evidence; counts refer to annotations, not unique physical objects.'}}))fs.writeFileSync(path.join(root,'data',file),JSON.stringify(data,null,2)+'\n');
console.log(JSON.stringify(payload.summary));
