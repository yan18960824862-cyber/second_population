const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),d=JSON.parse(fs.readFileSync(path.join(root,'data/census.json'))),ids=new Set(),aliases=new Set();
for(const r of d.records){
 assert(!ids.has(r.canonicalId));ids.add(r.canonicalId);
 for(const key of ['canonicalId','sourceId','sceneId','label','labelEn','category','categoryLabel','appear','disappear','tracking','keyframes','trajectory','thumb','archive','resourceData','populationEligible','source','confidence'])assert(key in r,'Missing '+key);
 for(const key of ['cameraId','timeRange','categoryOriginal','eligibilityStatus','auditEvidence','modelStatus','resourceVerificationStatus'])assert(key in r,'Missing unified route field '+key);
 assert.equal(r.categoryOriginal,r.category);assert.equal(r.timeRange.start,r.appear);assert.equal(r.timeRange.end,r.disappear);
 assert.equal(r.cameraId,r.sceneId==='legacy'?null:'CAM0'+r.sceneId.slice(-1));
 assert.equal(r.resourceVerificationStatus,'unverified');assert.equal(r.auditEvidence.independentVerification,false);
 if(r.sky){const raw=JSON.parse(fs.readFileSync(path.join(root,r.provenance.sourceFile))).objects.find(o=>o.objectId===r.sourceId);assert.deepEqual(r.annotation,raw,'Original observation changed '+r.canonicalId);}
 assert(r.appear<=r.disappear);assert(r.tracking.length>0);assert.equal(r.tracking.length,r.trajectory.length);assert(fs.existsSync(path.join(root,r.thumb)),'Missing thumb '+r.thumb);
 for(const a of r.sourceIds){const key=a.project+':'+a.sceneId+':'+a.sourceId;assert(!aliases.has(key));aliases.add(key)}
 for(let i=0;i<r.tracking.length;i++){const k=r.tracking[i];for(const key of ['t','x','y','w','h'])assert(Number.isFinite(k[key]));if(i)assert(k.t>=r.tracking[i-1].t);assert.equal(r.trajectory[i].x,k.x+k.w/2)}
 assert.equal(r.resourceData.status,'unverified-estimate');assert.equal(r.resourceData.verifiedValues.length,0);
 if(r.category==='person'||r.annotation.isAc)assert.equal(r.populationEligible,false);
 assert.equal(r.color,require('../integration/visual-rules.js').groups[require('../integration/visual-rules.js').groupIndex(r.annotation)].color);
 for(const q of Object.values(r.resourceData.quantities)){assert(q.unit&&q.source.path&&q.status==='simulated-estimate');}
}
assert.equal(d.records.filter(r=>r.sky).length,75);assert.equal(d.records.filter(r=>r.sceneId==='legacy').length,40);assert.equal(d.summary.uniquePhysicalObjects,null);
assert.deepEqual(d.records.filter(r=>r.sky).reduce((a,r)=>(a[r.category]=(a[r.category]||0)+1,a),{}),{industrial:15,infrastructure:13,vehicle:40,person:7});
assert.equal(d.summary.verifiedPopulationCount,null);
assert.equal(d.records.filter(r=>r.sky&&r.populationEligible!==false).length,63);
assert.equal(d.records.filter(r=>r.sky&&r.populationEligible===false).length,12);
for(const scene of d.scenes){assert(fs.existsSync(path.join(root,scene.video)));assert.equal(d.records.filter(r=>r.sceneId===scene.key).length,scene.count)}
console.log('PASS: 115 observations, 169 provenance aliases, 54 exact shared observations, 5 correct feed/video pairs; physical deduplication remains unresolved.');
